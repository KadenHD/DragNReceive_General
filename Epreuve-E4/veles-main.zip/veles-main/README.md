# PPE: Veles

Project made for our first year at PROMEO, Compiègne, France. This project was realized by Mei, Pierre, Abdel and Manon, from the BTS SIO 22

## Sign In page (default)

![SignIn](https://i.imgur.com/N6RXHSu.png)

## Home page

![Home](https://i.imgur.com/0cOlknm.png)

## An ebook page

![Ebook](https://i.imgur.com/Ji3PiZh.png)

You can find the Specs [HERE](https://docs.google.com/document/d/1IUhnsotoFMvK3Ad7eqgmo8SM1tYyUa-h--VlGKvGTlA/edit?usp=sharing)
