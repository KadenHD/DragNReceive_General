<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./style/footer.css">
</head>

<body>
    <footer class="footer">
        <div class="up">
            <ul id='links'>
                <li><a href="/FAQ">FAQ</a> -</li>
                <li><a href="mailto:test.hello@gmail.com">Contact</a> -</li>
                <li><a href="/PN">Privacy Notice</a> -</li>
                <li><a href="/COU">Condition of use</a></li>
            </ul>
        </div>

        <!-- I can't make it work for now-->
        <!--<div class="img">
            <ul id= 'images'>
                <li><a href="https://github.com/Opalie/ppe-hibouk"><img src="img/github.png" alt="Source Code"></a></li>
                <li><a href="https://www.promeo-formation.fr/nos-centres/compiegne"><img src="img/promeo.png" alt="Promeo Compiègne"></a></li>
            </ul>
        </div>-->

    </footer>
</body>

</html>