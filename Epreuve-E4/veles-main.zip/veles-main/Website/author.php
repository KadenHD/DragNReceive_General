<?php

include_once './include/_dbSettings.php';


// Check to make sure the id parameter is specified in the URL
if (isset($_GET['author_id'])) {
    // Prepare statement and execute, prevents SQL injection
    $stmt = $bdd->prepare('SELECT * FROM author WHERE author_id = ?');
    $stmt->execute([$_GET['author_id']]);
    // Fetch the author from the database and return the result as an Array
    $author = $stmt->fetch(PDO::FETCH_ASSOC);
    // Check if the author exists (array is not empty)

    if (!$author) {
        // Simple error to display if the id for the author doesn't exists (array is empty)
        exit('Author does not exist!');
    }
} else {
    // Simple error to display if the id wasn't specified
    exit('Author ID does not exist!');
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style/author.css" />
    <title><?= $author['author_firstname'] ?> <?= $author['author_lastname'] ?></title>
</head>

<?php
include_once './include/navbar.php';
?>

<body>

    <div class="page">


        <div class="left">
            <img src="<?= $author['author_pic'] ?>" alt="author picture">

            <h3>
                <!--fuction for birth date format-->
                <?php
                $datebirth = date_create($author['author_birth']);
                echo date_format($datebirth, 'jS M Y');
                ?>
                -
                <!--If author_death is NULL then echo Nowadays, else echo deathtime-->
                <?php
                if (is_null($author['author_death'])) {
                    echo 'Nowadays';
                } else {
                    $datedeath = date_create($author['author_death']);
                    echo date_format($datedeath, 'jS M Y');
                }
                ?>
            </h3>
        </div>

        <div class="right">
            <h1><?= $author['author_firstname'] ?> <?= $author['author_lastname'] ?></h1>
            <hr>
            <p><?= $author['author_bio'] ?></p>

            <div class="authorbooks">
                <!--need to implement this feature-->
            </div>

        </div>

    </div>

</body>

</html>

<?php include './include/copyright.php'; ?>

<!--/author.php?author_id=?-->